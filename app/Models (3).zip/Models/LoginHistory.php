<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LoginHistory extends Model
{
    use HasFactory;
    protected $table = "login_history";
    public $timestamps = false;
    protected $fillable = ['emp_id','login_time'];
}
