<?php

namespace App\Imports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use App\Models\Stock;
use Maatwebsite\Excel\Concerns\WithStartRow;
use DB;

class ImportStock implements ToCollection,WithStartRow
{
    /**
    * @param Collection $collection
    */
    public function collection(Collection $collection)
    {
    	foreach ($collection as $row) {
           
            DB::table('stock_details')->insert([
                'category_id' => $row[0],     
                'branch_id' => $row[6],
                'brand_name' => $row[1],
                'product_id'=>$row[7],
                'price'=>$row[9],
                'vendor_id'=>$row[4],
                'product_type'=>$row[5],
                'device_id'=>$row[8],
                'quantity'=>$row[2],
                'remaining_quantity'=>$row[3],
                'created_by'=>$row[10],

            ]);
        }
        
    }
    public function startRow(): int
    {
        return 2;
    }
}
